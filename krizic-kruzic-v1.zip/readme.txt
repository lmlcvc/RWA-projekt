- u images je 8 custom reklama i ostale potrebne slike
- čovječuljka koji pleše i pozadinu možemo dodati i kad sve završimo jer je to isto za sve

- izgled stranice mijenja se na malim ekranima za lakše korištenje
- na malim ekranima nestaju reklame -> trebalo bi to zamijeniti npr. slikom posjetite.gif (jednom od njenih verzija) -> ja sam mislila da to bude iznad bannera ali NE ZNAM TO URADITI

- pls provjerite dal ok izgleda i na vašim ekranima sve
